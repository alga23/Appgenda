package com.example.proyecto_final

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    private lateinit var nombreActividad: EditText
    private var registrosList: MutableList<Actividades> = ArrayList()
    private lateinit var recyclerViewBoton: Button
    private lateinit var adapter: RecyclerViewAdapter
    private  val gson = Gson()






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nombreActividad = findViewById(R.id.nombreActividad)
        val guardarButton: Button = findViewById(R.id.guardar)

        val preferences: SharedPreferences = getSharedPreferences("registros", Context.MODE_PRIVATE)

        // Cargamos otra vez todas
        //las actividades que hay en
        //el SharedPreferences
        val actividadesJson = preferences.getString("actividades", null)
        if (actividadesJson != null) {
            try {
                val lista = gson.fromJson(actividadesJson, Array<Actividades>::class.java).toMutableList()
                registrosList = lista
            } catch (e: JsonSyntaxException) {
                Log.e("MainActivity", "Error al leer JSON de SharedPreferences", e)
            }
        }

        guardarButton.setOnClickListener {
            val textoIngresado = nombreActividad.text.toString()
            if (textoIngresado.isNotEmpty()) {
                // Añadimos una nueva actividad a la lista
                registrosList.add(Actividades(textoIngresado))

                // Convertir la lista de actividades a una cadena de texto en formato JSON
                val actividadesJsonNuevo = gson.toJson(registrosList)

                // Guardar la cadena de texto en formato JSON en las SharedPreferences
                val editor: SharedPreferences.Editor = preferences.edit()
                editor.putString("actividades", actividadesJsonNuevo)
                editor.apply()

                // Borramos texto
                nombreActividad.text.clear()
            } else {
                Toast.makeText(this, "Ingresa un nombre de actividad válido", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }



    // metodo que utilizamos
    //para guardar actividad
    fun agregarActividad() {
        //agarramos el texto
        val textoIngresado = nombreActividad.text.toString()

        if (textoIngresado.isNotEmpty()) {
            val nuevaActividad = Actividades(textoIngresado)
            registrosList.add(nuevaActividad)
            guardarActividad(nuevaActividad)
            adapter.notifyDataSetChanged()
            nombreActividad.text.clear()
        } else {
            Toast.makeText(this, "Ingresa un nombre de actividad válido", Toast.LENGTH_SHORT).show()
        }
    }


    //
    private fun guardarActividad(actividad: Actividades) {
        val preferences: SharedPreferences = getSharedPreferences("registros", Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = preferences.edit()

        // Guarda cada actividad en un conjunto para luego recuperarlo
        val actividadesSet = preferences.getStringSet("actividades", mutableSetOf()) ?: mutableSetOf()
        actividadesSet.add(gson.toJson(actividad))
        editor.putStringSet("actividades", actividadesSet)
        editor.apply()
    }





    fun guardar(view: View) {
        val nombre = nombreActividad.text.toString()
        val nuevaActividad = Actividades(nombre)
        registrosList.add(nuevaActividad)

        val preferences: SharedPreferences = getSharedPreferences("registros", Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = preferences.edit()

        val actividadesJson = gson.toJson(registrosList)
        editor.putString("actividades", actividadesJson)
        editor.apply()

        // Iniciar el RecyclerViewActivity y pasar el nombre como extra
        val intent = Intent(this, RecyclerViewActivity::class.java)
        intent.putExtra("nombreActividad", nombre)
        startActivity(intent)

        Toast.makeText(this, "Actividad guardada", Toast.LENGTH_SHORT).show()
    }




    fun irARecycler(view: View) {
        val intentBotonRecycler = Intent(this, RecyclerViewActivity::class.java)
        startActivity(intentBotonRecycler)
    }

    //funcion que nos lleva
    //al RecyclerViewAdapter
    //(no se usa)
    fun onClick(v: View) {
        val i = Intent(this@MainActivity, RecyclerViewAdapter::class.java)
        startActivity(i)
     }

    //Metodo que guardara nuevas actividades

    fun añadirActividad(){

        //agarramos el texto
        val textoIngresado = nombreActividad.text.toString()

        if (textoIngresado.isNotEmpty()) {
            val nuevaActividad = Actividades(textoIngresado)
            registrosList.add(nuevaActividad)
            adapter.notifyDataSetChanged()
            nombreActividad.text.clear()
        } else {
            Toast.makeText(this, "Ingresa un nombre de actividad válido", Toast.LENGTH_SHORT).show()
        }
    }

    }









