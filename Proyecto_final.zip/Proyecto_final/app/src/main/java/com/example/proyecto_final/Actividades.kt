package com.example.proyecto_final

import java.util.*

data class Actividades(val nombre: String, var fecha: Date? = null, var completada: Boolean? = null)
