package com.example.proyecto_final

import android.app.DatePickerDialog
import android.content.ClipDescription
import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import java.util.*

class RecyclerViewAdapter(var context: Context, var listaActividades:MutableList<Actividades>):RecyclerView.Adapter<RecyclerViewAdapter.RegistroViewHolder>(){

    class RegistroViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        lateinit var nombreActividad: TextView
        lateinit var fechaActividad: TextView
        lateinit var completada: CheckBox
        lateinit var botonEliminar: Button
        lateinit var descripcionActividad: TextView
        lateinit var guardarDescription: Button

        init {
            nombreActividad = itemView.findViewById(R.id.nombreTextView)
            fechaActividad = itemView.findViewById(R.id.fechaTextView)
            completada = itemView.findViewById(R.id.completadaCheckBox)
            botonEliminar = itemView.findViewById(R.id.btn_eliminar)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RegistroViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_registro, parent, false)
        return RegistroViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: RegistroViewHolder, position: Int) {
        val registroActividad = listaActividades[position]
        holder.nombreActividad.text = registroActividad.nombre
        holder.fechaActividad.text = registroActividad.fecha?.toString()
        holder.completada.isChecked = registroActividad.completada ?: false


        //meotod que se activa al pulsar el
        //botonEliminar. Provoca que
        //la actividad se elimine
        //de forma persistente del
        //SharedPreferences
        holder.botonEliminar.setOnClickListener {
            val actualPosition = holder.adapterPosition
            listaActividades.removeAt(actualPosition)
            notifyItemRemoved(actualPosition)

            val gson = Gson()
            val actividadesJsonNuevo = gson.toJson(listaActividades)
            val preferences: SharedPreferences = context.getSharedPreferences("registros", Context.MODE_PRIVATE)
            val editor: SharedPreferences.Editor = preferences.edit()
            editor.putString("actividades", actividadesJsonNuevo)
            editor.apply()

            Toast.makeText(context, "Actividad eliminada", Toast.LENGTH_SHORT).show()
        }

        // Configurar el Checkbox
        holder.completada.setOnCheckedChangeListener { _, isChecked ->
            registroActividad.completada = isChecked
        }

        // Configurar el DatePickerDialog
        holder.itemView.setOnClickListener {
            val c = Calendar.getInstance()
            val año = c.get(Calendar.YEAR)
            val mes = c.get(Calendar.MONTH)
            val dia = c.get(Calendar.DAY_OF_MONTH)

            val dpd = DatePickerDialog(context, DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                val selectedDate = GregorianCalendar(year, monthOfYear, dayOfMonth).time
                val actualPosition = holder.adapterPosition
                listaActividades[actualPosition].fecha = selectedDate

                // Notifica al adaptador que los datos han cambiado
                this.notifyItemChanged(actualPosition)
            }, año, mes, dia)
            dpd.show()
        }
    }

    override fun getItemCount(): Int {
        return listaActividades.size
    }
}
