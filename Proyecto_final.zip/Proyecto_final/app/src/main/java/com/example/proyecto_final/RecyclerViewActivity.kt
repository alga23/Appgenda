package com.example.proyecto_final

import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class RecyclerViewActivity : AppCompatActivity() {
    //inicializamos ciertas variavbles
    //necesarias como el RecyclerView y
    //su adaptador
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: RecyclerViewAdapter
    private var listaActividades: MutableList<Actividades> = mutableListOf()
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recyclerview)
        recyclerView = findViewById(R.id.NuevActividad)
        val layoutManager = LinearLayoutManager(this)


        //creamos una instancia de SharedPreferences
        //para poder almacenar nuestras actividades
        val preferences: SharedPreferences = getSharedPreferences("registros", Context.MODE_PRIVATE)
        val actividadesJson: String? = preferences.getString("actividades", null)


        //convertimos el json (en caso de que no sea nulo)
        //en un objeto type que convierte el Json
        //en una lista mutable de objetos de la clase
        //actividades. Finalmente, asignamos
        //a la variable listaActividades
        // la conversion
        if (actividadesJson != null) {
            val type = object : TypeToken<MutableList<Actividades>>() {}.type
            listaActividades = gson.fromJson(actividadesJson, type)
        }


        recyclerView.layoutManager = layoutManager
        adapter = RecyclerViewAdapter(this, listaActividades)
        recyclerView.adapter = adapter
    }
}
